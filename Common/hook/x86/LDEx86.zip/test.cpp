// test.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "lde32.h"
#include <windows.h>

int main(int argc, char* argv[])
{
    LPVOID func = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    for (int i=0; i<20;)
    {
        int ilen = LDE(func, 0);
        printf("%d\n", ilen);
        i += ilen;
        func = (LPVOID)((DWORD)func+ilen);
    }
	printf("Hello World!\n");
	return 0;
}

